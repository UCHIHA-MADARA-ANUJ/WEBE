<!-- ═══════════════════════════════════════════════════════════════════════
     ANUJ PHULERA — profile README
     github.com/Anuj-Phulera
     -------------------------------------------------------------------
     Nothing left to replace — details are live.

     Keep all six .svg files next to this README in the repo root.
     Assets: banner.svg · banner-light.svg · emblem.svg · registry.svg
             stats.svg · projects.svg · divider.svg · typing.svg
     ═══════════════════════════════════════════════════════════════════════ -->

<div align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="./banner.svg">
    <source media="(prefers-color-scheme: light)" srcset="./banner-light.svg">
    <img src="./banner.svg" alt="Anuj Phulera" width="100%" />
  </picture>
</div>

<br/>

<div align="center">
  <img src="./typing.svg" alt="I don't chase attention. I build things that command it." />
</div>

<div align="center">
  <img src="./emblem.svg" width="96" alt="Uzumaki spiral" />
</div>

<h1 align="center">ANUJ PHULERA</h1>

<p align="center">
  <code>SEALING CORPS</code> &nbsp;·&nbsp;
  <code>INTERFACE ENGINEER</code> &nbsp;·&nbsp;
  <code>GURUGRAM, INDIA</code>
</p>

<p align="center">
  <a href="#-selected-work"><b>Work</b></a> &nbsp;·&nbsp;
  <a href="#-the-path"><b>The Path</b></a> &nbsp;·&nbsp;
  <a href="https://github.com/Anuj-Phulera/WEBE"><b>Live Site</b></a> &nbsp;·&nbsp;
  <a href="mailto:anuj.phulera.work@gmail.com"><b>Email</b></a> &nbsp;·&nbsp;
  <a href="https://discord.com/users/1417462466304016494"><b>Discord</b></a>
</p>

<br/>

<div align="center">
  <img src="./registry.svg" width="100%" alt="Shinobi registration" />
</div>

<img src="./divider.svg" width="100%" alt="" />

## ⦿ The Seal

**I don't chase attention. I build things that command it.**

Every project here starts from the same belief: software should adapt to the
person using it, not the other way round. Not a theme switcher — the structure.
The layout, the hierarchy, what's available and what's hidden, decided at
runtime by watching how you actually read.

> *A random shuffle is noise. A decided one is a signal.*

<img src="./divider.svg" width="100%" alt="" />

## ⦿ Right Now

| | |
|---|---|
| 🔴 **Building** | **DEEP FIELD** — a living atlas of the cosmos with no fixed interface. Six structural paradigms, eleven live behavioural signals, and an engine that earns the right to rearrange the page. |
| 🩸 **Growing** | **VERDE** — a vertical farm that waters itself. ESP32 firmware, TensorFlow Lite disease classifier, custom PCB, Hindi/English control channel. |
| 🗡 **Shipping** | **NIRMAAN** — an AI-powered e-waste pickup network for India. Three roles, live routing, bookings that run end to end. |

<img src="./divider.svg" width="100%" alt="" />

## ⦿ Selected Work

<div align="center">
  <img src="./projects.svg" width="100%" alt="Eight projects" usemap="#works" />
</div>

<map name="works">
  <area shape="rect" coords="10,10,290,206"  href="https://github.com/Anuj-Phulera/Verde-Portfolio" alt="Verde Portfolio" />
  <area shape="rect" coords="310,10,590,206" href="https://github.com/Anuj-Phulera/Verde-APP" alt="Verde App" />
  <area shape="rect" coords="610,10,890,206" href="https://github.com/Anuj-Phulera/Nirmaan-APP" alt="Nirmaan App" />
  <area shape="rect" coords="910,10,1190,206" href="https://github.com/Anuj-Phulera/NIrman-Portfolio" alt="Nirman Portfolio" />
  <area shape="rect" coords="10,226,290,422" href="https://github.com/Anuj-Phulera/Skill-Verse" alt="Skill-Verse" />
  <area shape="rect" coords="310,226,590,422" href="https://github.com/Anuj-Phulera/Resonate" alt="Resonate" />
  <area shape="rect" coords="610,226,890,422" href="https://github.com/Anuj-Phulera/Rakshabandhan" alt="Rakshabandhan" />
  <area shape="rect" coords="910,226,1190,422" href="https://github.com/Anuj-Phulera/Verde-Previous-Portfolio" alt="Verde Previous Portfolio" />
</map>

| | | |
|---|---|---|
| **[VERDE PORTFOLIO](https://github.com/Anuj-Phulera/Verde-Portfolio)**<br/><sub>closed-loop farm compendium</sub> | **[VERDE APP](https://github.com/Anuj-Phulera/Verde-APP)**<br/><sub>live telemetry mission control</sub> | **[NIRMAAN APP](https://github.com/Anuj-Phulera/Nirmaan-APP)**<br/><sub>e-waste pickup network</sub> |
| **[NIRMAN PORTFOLIO](https://github.com/Anuj-Phulera/NIrman-Portfolio)**<br/><sub>sixteen-act narrative</sub> | **[SKILL-VERSE](https://github.com/Anuj-Phulera/Skill-Verse)**<br/><sub>skill analytics platform</sub> | **[RESONATE](https://github.com/Anuj-Phulera/Resonate)**<br/><sub>algorithmic empathy</sub> |
| **[RAKSHABANDHAN](https://github.com/Anuj-Phulera/Rakshabandhan)**<br/><sub>1,450 km, one thread</sub> | **[VERDE PREVIOUS](https://github.com/Anuj-Phulera/Verde-Previous-Portfolio)**<br/><sub>the original build</sub> | <sub>&nbsp;</sub> |

<img src="./divider.svg" width="100%" alt="" />

## ⦿ The Path

Interfaces that change shape are easy to make **unusable**. Anyone can shuffle a
grid. The hard part was never the shuffling.

> **The hard part is earning the right to shuffle.**

So DEEP FIELD only reconstructs itself when the engine has **evidence** — a
confident read, and a clear margin over the runner-up — and never more than once
every nine seconds. It shows you what changed and why. It lets you pin a
structure and switch the engine off. It never loses your place.

Every project here is an argument for the same idea: *adapt, but never at the
cost of trust.*

<img src="./divider.svg" width="100%" alt="" />

## ⦿ Attribute Sheet

<div align="center">
  <img src="./stats.svg" width="100%" alt="Attribute sheet" />
</div>

<img src="./divider.svg" width="100%" alt="" />

## ⦿ Run It

Every repo here runs with the same three commands. No build servers, no Docker, no ceremony.

```bash
npm install
cp .env.example .env.local    # VERDE APP and NIRMAAN APP only
npm run dev                   # → http://localhost:3000
```

DEEP FIELD and CommitQuest need nothing at all — one is Vite, the other is plain
files you can open directly.

<img src="./divider.svg" width="100%" alt="" />

## ⦿ Contact

Open an issue on any repo, or reach me directly — I answer both.

<p>
  <a href="mailto:anuj.phulera.work@gmail.com"><img src="https://img.shields.io/badge/EMAIL-anuj.phulera.work%40gmail.com-C1272D?style=flat-square&labelColor=0C0A10" alt="Email" /></a>
  <a href="https://discord.com/users/1417462466304016494"><img src="https://img.shields.io/badge/DISCORD-madara._.uchiha_-4FB3D9?style=flat-square&labelColor=0C0A10" alt="Discord" /></a>
</p>

<img src="./divider.svg" width="100%" alt="" />

<div align="center">

<img src="./emblem.svg" width="62" alt="" />

<br/><br/>

<sub>Gurugram, Haryana · building things that shouldn't fit in a browser tab</sub>

<br/><br/>

<a href="https://github.com/Anuj-Phulera?tab=repositories"><b>Repositories</b></a> &nbsp;·&nbsp;
<a href="https://github.com/Anuj-Phulera/WEBE"><b>DEEP FIELD</b></a> &nbsp;·&nbsp;
<a href="mailto:anuj.phulera.work@gmail.com"><b>Email</b></a> &nbsp;·&nbsp;
<a href="https://discord.com/users/1417462466304016494"><b>Discord</b></a>

</div>
